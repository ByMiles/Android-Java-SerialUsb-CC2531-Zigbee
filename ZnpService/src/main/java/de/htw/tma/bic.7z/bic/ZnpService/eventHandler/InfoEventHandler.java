package de.htw.tma.bic.ZnpService.eventHandler;

public interface InfoEventHandler {

    void setInfoText(String usbInfo);
}
